package org.spigotmc.builder;

public enum Repository
{
    BUKKIT,
    CRAFTBUKKIT,
    SPIGOT;
}
