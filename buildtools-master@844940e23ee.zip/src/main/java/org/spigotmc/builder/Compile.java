package org.spigotmc.builder;

public enum Compile
{
    NONE,
    CRAFTBUKKIT,
    SPIGOT;
}
